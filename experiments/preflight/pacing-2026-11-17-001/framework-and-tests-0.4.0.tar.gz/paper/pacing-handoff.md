# Provider request pacing

Pacing is implemented and verified offline. No paid requests or new experiment
runs were made for this change. The previous raw runs, index, review packets,
and frozen experiment configurations remain preserved.

Use `configs/adaptive.anthropic.paced.local.yaml` for a future fresh plan. It keeps
direct Anthropic Haiku 4.5 for routing, navigation, and answers, and reuses the
existing Qwen index and embedding connection. Its settings are:

| Control | Value |
| --- | --- |
| Concurrent requests per endpoint in one process | 1 |
| Minimum time between request starts | 6 seconds |
| Maximum starts per rolling minute | 10 |
| Answer deadline, including pacing wait | 90 seconds |
| Routing deadline, including pacing wait | 90 seconds |
| Combined retrieval deadline, including pacing wait | 300 seconds |
| Total run bounds | 270 planned jobs; 90 minutes; $5 estimated cost |

All chat roles share one gate. A shared embedding/chat endpoint uses the stricter
of their settings. Separate processes have independent gates; use one experiment
process for the provider account. These controls do not establish the account's
token quotas. Anthropic also limits input and output tokens per minute; request
spacing can reduce bursts but cannot guarantee successful calls. See the
[official rate-limit guidance](https://platform.claude.com/docs/en/api/rate-limits).

The gate applies numeric or HTTP-date `Retry-After` cooldowns on HTTP 402, 429,
and 503. Exhausted Anthropic remaining/reset headers also impose a cooldown.
Server delays are bounded at one hour; a delay that cannot fit a caller's
remaining deadline is rejected before network delegation. Failed calls are
never automatically retried. A response timeout with missing usage still has
unknown cost and stops a cost-bounded run. The former 30-second timeout was not
proof of a provider rate-limit response.

Queue waits consume stage/run wall time and appear in job elapsed time. Raw
provider-call elapsed time starts after pacing admission. Pre-network rejection
or cancellation adds no provider attempt or unknown usage. The journal also
subtracts admission and durable-intent time from the caller's remaining deadline.
Persistent model/index identities and old answer-review hashes are unchanged.

Verification: 194 focused tests passed, including deterministic clock tests,
HTTP mock transports, shared-role pacing, cooldowns, deadline rejection,
cancellation, journal accounting, index recovery, CLI and runner integration.
Ruff lint/format and configuration validation passed. These checks exercise
contracts; the paced setup has not been live-tested.

Pacing makes execution slower. At ten starts per minute a 90-minute run permits
at most roughly 900 starts per endpoint before other overhead; the 270-job plan
can require more calls. The unchanged time/cost bounds may therefore leave a
partial run. Freeze a workload and budget plan before any future paid execution,
and use a new output directory rather than appending to a prior partial run.
